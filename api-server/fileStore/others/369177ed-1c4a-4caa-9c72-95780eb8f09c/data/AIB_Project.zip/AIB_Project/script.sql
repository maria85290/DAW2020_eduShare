alter table dim_medicine modify desc_med varchar(255);
alter table dim_icd9_classification modify description_level4 varchar(255);
alter table dim_icd9_classification modify description_level3 varchar(255);
alter table dim_icd9_classification modify description_level5 varchar(255);
alter table dim_icd9_classification modify description_level2 varchar(255);
alter table dim_icd9_classification modify description_level1 varchar(255);
alter table dim_procedure modify description_procedure varchar(550);



# ----------------------------------------------------------------------------------------
INSERT INTO Dim_Color (id_color, desc_color)  
SELECT DISTINCT ID_COLOR, DESC_COLOR
FROM urgency_episodes;

# ----------------------------------------------------------------------------------------
INSERT INTO Dim_Pacient (date_of_birth, sex, district)
SELECT STR_TO_DATE(date_of_birth, '%d/%m/%Y %H:%i'), sex, district FROM urgency_episodes;

# ----------------------------------------------------------------------------------------
INSERT INTO Dim_Reason(id_reason, desc_reason)
SELECT DISTINCT ID_REASON, DESC_REASON FROM urgency_episodes;

# ----------------------------------------------------------------------------------------
INSERT INTO Dim_Cause(id_cause, description_cause)
SELECT DISTINCT ID_EXT_CAUSE, DESC_EXTERNAL_CAUSE FROM urgency_episodes;

# ----------------------------------------------------------------------------------------
INSERT INTO Dim_Destination (id_destination, desc_destination)
SELECT DISTINCT ID_DESTINATION, DESC_DESTINATION FROM urgency_episodes;

# ----------------------------------------------------------------------------------------
INSERT INTO Dim_Intervention(id_intervention, description_interv)
SELECT DISTINCT ID_INTERVENTION, DESC_INTERVENTION FROM urgency_procedures;

# ----------------------------------------------------------------------------------------
INSERT INTO Dim_Medicine (cod_med, desc_med)
SELECT DISTINCT COD_DRUG, DESC_DRUG FROM urgency_prescriptions;

# ----------------------------------------------------------------------------------------
INSERT INTO Dim_Exam (cod_exam, desc_exame)
SELECT DISTINCT NUM_EXAM, DESC_EXAM FROM urgency_exams;

# ----------------------------------------------------------------------------------------
INSERT INTO Dim_ICD9_Classification (cod_diagnosis, levelMax, description_level1, description_level2, description_level3, description_level4, description_level5)
SELECT case level_5_code when '' then (case level_4_code when '' then cast(level_3_code as float) else cast(level_4_code as float) end) else cast(level_5_code as float) END, 
		case level_5_code when '' then (case level_4_code when '' then 3 else 4 end) else 5 END,
        level_1_desc, level_2_desc, level_3_desc, level_4_desc, case level_5_desc when '' then null else level_5_desc end
        
FROM icd9_hierarchy;

# TABELAS COM FK
# ----------------------------------------------------------------------------------------
#id_diagnosis is AI
alter table dim_diagnosis modify desc_diagnosis varchar(255);
INSERT INTO Dim_Diagnosis (date_diagnosis, desc_diagnosis, id_prof_diagnosis, id_classification)
SELECT STR_TO_DATE(t1.dt_diagnosis, '%d/%m/%Y %H:%i'), t1.DIAGNOSIS, t1.ID_PROF_DIAGNOSIS, cast(t2.id_classification as float)
FROM urgency_episodes t1, dim_icd9_classification t2
where t2.cod_diagnosis = cast(t1.cod_diagnosis as float);

# ----------------------------------------------------------------------------------------
#id_discharge is AI
INSERT INTO Dim_Discharge (date_discharge, id_prof_discharge, id_reason, id_destination)
SELECT STR_TO_DATE(t1.dt_discharge, '%d/%m/%Y %H:%i'), t1.ID_PROF_DISCHARGE, t2.id_reason, t3.id_destination
FROM urgency_episodes t1, Dim_Reason t2, Dim_Destination t3
WHERE t3.ID_DESTINATION = t1.ID_DESTINATION AND t2.id_reason = t1.ID_REASON;

#------------------------------------------------------------------------------
#id_procedure is AI
INSERT INTO Dim_Procedure (date_procedure, id_professional, id_prescription, id_intervention, description_procedure)
SELECT t1.urg_episode, STR_TO_DATE(t1.DT_BEGIN, '%Y-%m-%d %H:%i:%s'), t1.ID_PROFESSIONAL, t1.ID_INTERVENTION, t1.NOTE
FROM urgency_procedures t1, Dim_Intervention t2
WHERE t1.ID_INTERVENTION = t2.ID_INTERVENTION;

#------------------------------------------------------------------------------
INSERT INTO Dim_Prescription (id_prescription, id_professional, date_presc, quantity, posology, id_cod_med, id_procedure)
SELECT t1.cod_prescription, t1.id_prof_prescription, t1.dt_prescription, t1.qt, t1.posology, t2.id_cod_med, t3.id_procedure
FROM urgency_prescriptions t1, dim_medicine t2, dim_procedures t3
WHERE t2.cod_med = t1.cod_drug and t3.id_prescription = t1.id_prescription;

#------------------------------------------------------------------------------
INSERT INTO Dim_Triage (id_triage, data_triage, id_prof_triage, id_color, pain_scale)
SELECT t1.id_triage, t1.dt_triage, t1.id_prof_triage, t2.id_color, t1.pain_scale
FROM urgency_episodes t1, dim_color t2
WHERE t1.color = t2.color;

#------------------------------------------------------------------------------
#falta acabar
INSERT INTO Fact_Episode (id_urge_episode, id_paciente, id_cause, id_discharge, id_diagnosis, id_prescription, id_exam, id_triage)
SELECT t1.urg_episode, t2.id_pacient, t1.id_cause, t1.id_discharge, t1.id_diagnosis, t3.id_exam, t1.id_triage
FROM urgency_episodes t1, dim_pacient t2, dim_exam t3
WHERE t2.sex = t1.sex and t2.district = t1.district and t2.date_of_birth = t1.date_of_birth and t3.;

