
#include <stdio.h>

#include <stdlib.h>

#include <string.h>




#define MAXTERMOS 6





typedef struct sTermo

{

  int exp;

  float coef;

} Termo;




typedef struct sPolinomio

{

  int ntermos;

  Termo termos[MAXTERMOS];

} Polinomio;





float valor(Polinomio p, int x)

{

  int i=0;

  float res=0.0;

  while (i<p.ntermos)

  {

    res=(p.termos[i].coef)*(x^(p.termos[i].exp));

    i++;

  }

  printf ("Valor: %f \n", res);

  return res;

}




int grau(Polinomio p)

{

  int i=0, maior=0;

  while (i<p.ntermos)

  {

    if (p.termos[i].exp>maior)

      maior=p.termos[i].exp;

    i++;

  }

  printf ("Grau: %d \n", maior);

  return maior;

}




Polinomio derivada(Polinomio p)

{

  Polinomio aux;

  int i=0;

  while (i<p.ntermos)

  {

    aux.termos[aux.ntermos].coef = p.termos[i].coef * p.termos[i].exp;

    aux.termos[aux.ntermos].exp = (p.termos[i].exp)-1;

    aux.ntermos++;

  }

  i++;

  return aux;

}




Termo consTermo(int n, float ter[])

{
  int i=0,x=0;

  Termo t;

  for (i=0;i<n;i++)

  {

    t.exp = ter[x];

    x++;

    t.coef = ter[x];

    x++;

  }

  return t;

}




Polinomio consPol(int n, Termo t)

{

  Polinomio p;

  p.ntermos = n;

  p.termos[0] = t;


  return p;

}




int main()

{

  float ter[]={2,2,3,3};

  Polinomio p1 = consPol(2,consTermo(2, ter));

  valor(p1, 1);

  grau(p1);

  
return 0;

}


