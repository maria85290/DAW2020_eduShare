#include "parques.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

LParque inserirParque(LParque complexo, Parque p){
    LParque cres = malloc(sizeof(NLParque));
    cres->p = p;
    cres->seg = complexo;
    
    return cres;
}

int contaOcupados(Llugar lista){
    if(lista == NULL) return 0;
    else
        return 1 + contaOcupados(lista->seg);
}

void listarParque(Parque p){
    printf("%s: lugares = %d, ocupados = %d\n", p.nparque, p.nlugares, contaOcupados(p.ocupados));
}

// Lista o complexo de parques na forma:
//    P1: lugares = x, ocupados = y ...
void listar( LParque lp ){
    printf("------------------------------------------------------\n");
    while(lp != NULL){
        listarParque(lp->p);
        lp = lp->seg;
    }
}

int verOcupacao(int lugar, Llugar ocupados){
    while(ocupados != NULL && ocupados->lugar != lugar)
        ocupados = ocupados->seg;

    return (ocupados == NULL) ? 1 : 0;
}

int disponivel( LParque lp, Nome p, int lugar ){
    while(lp != NULL && strcmp(p, lp->p.nparque) != 0) 
        lp = lp->seg;

    return (lp == NULL || lp->p.nlugares == contaOcupados(lp->p.ocupados)) ? 
                                                        0 : verOcupacao(lugar, lp->p.ocupados);
}

Llugar insOcupacao(Llugar lista, Llugar l){
    if(lista == NULL || lista->lugar > l->lugar){
        l->seg = lista;
        return l;
    }
    else {
        lista->seg = insOcupacao( lista->seg, l);
        return lista;
    }
}

LParque estacionaAux(LParque lp, Nome p, int lugar){
    Llugar novo = malloc(sizeof(NLlugar));
    novo->lugar = lugar;

    LParque lpaux = lp;

    while(strcmp(p, lpaux->p.nparque) != 0) 
        lpaux = lpaux->seg;
    
    lpaux->p.ocupados = insOcupacao(lpaux->p.ocupados, novo);
    return lp;
}


LParque estaciona( LParque lp, Nome p, int lugar){
    if(disponivel(lp, p, lugar))
        return estacionaAux(lp, p, lugar);
    else
        return lp;
}


void listardisponibilidades( LParque lp );

