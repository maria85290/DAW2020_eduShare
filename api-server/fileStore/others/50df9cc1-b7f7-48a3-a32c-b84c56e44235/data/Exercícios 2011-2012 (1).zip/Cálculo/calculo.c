﻿
#include <stdio.h>




/** Mínimo múltiplo comun **/

int mmc (int a, int b)

{
  int m;

  if (a>b)

  {

    m=a;

    while (m%b != 0)

    {

      m+=a;

    }

  }

  else

  {

    m=b;

    while (m%a != 0)

    {

      m+=b;

    }

  }

  return m;

}





/** Máximo múltiplo comum **/

int maxmc (int a, int b)

{

  int res = a;

  while (res%b != 0)

  {

    res = res+a;

  }

  return res;

}



/** Máximo múltiplo comum recursivo **/
int maxmc_rec (int a, int b)

{

  return maxmc_rec_aux(a,b,a);

}


int maxmc_rec_aux (int a,int b, int t)

{

  int res = t;

  if (res%b != 0)

  res = maxmc_rec_aux(a, b, t+a);
  return res;

}






/** Máximo divisor comun **/
int mdc (int a, int b)

{

  int temp;

  if (a<b)

  {

    temp = a;

    a = b;

    b = temp;

  }

  while (a%b != 0)

  {

    temp = b;

    b = a%b;

    a = temp;

  }


  return b;

}




/** Soma os números ímpares entre 1 e n **/

int soma_n_impares (int n)

{

  int res = 0, x = 1;

  while (x<=n)

  {

    res+=x;

    x+=2;

  }

  return res;

}




/** Soma os números ímpares entre 1 e n recursivamente **/

int soma_n_impares_rec (int n)

{

  int res = 0 ;

  if (n != 0)

  {

    if ((n%2) != 0)

    {

      if (n == 1)

        res = 1;

      else

        res = n + soma_n_impares_rec(n-2);
    }

    else

      res = soma_n_impares_rec(n-1);

  }

  return res;

}






/** Resto da divisão inteira **/

int resto (int a, int b)

{

  while (a>=b)

  {

    a = a-b;

  }

  return a;

}




/** Resto da divisão inteira recursivo **/

int resto_rec (int a, int b)

{

  int res;

  if (a<b)

    res = a;

  else

    res = resto_rec(a-b, b);

  return res;

}



/** Divisão inteira **/




int div_int (int a,int b)

{

  int res = 0;

  while (a>=b)

  {

    res++;

    a-=b;

  }

  return res;

}




/** Divisão inteira recursivo **/



int div_int_rec (int a,int b)

{

  int res = 0;

  if(a<b)

    res = 0;

  else
    res = 1 + div_int_rec(a-b, b);
  return res;

}





/** Divisores de um número **/

int divisores (int n)

{

  int i = 1, res = 0;

  while (i<=n)

  {


    if (n%i == 0)
      res++;

      i++;

  }

  return res;

}




/** Divisores de um número recursivo **/
int divisoresrec (int n)

{

  return divrecaux (n,n);

}


int divrecaux (int a, int b)

{

  int res = 0;

  if (b>0)

  {

    if (a%b == 0)

      res = 1 + divrecaux (a, b-1);

    else

      res = divrecaux (a, b-1);

  }

  return res;

}



int main()

{

  int n1,n2;

  /*

  printf("Introduza o primeiro número: \n");

  scanf("%d",&n1);

  printf("Introduza o segundo número: \n");

  scanf("%d",&n2);

  printf("O mínimo múltiplo comum é: %d \n",mmc(n1,n2));

  printf("\n*********************************\n");
  printf("Introduza o primeiro número: \n");

  scanf("%d",&n1);

  printf("Introduza o segundo número: \n");

  scanf("%d",&n2);

  printf("O máximo múltiplo comum é: %d \n",maxmc(n1,n2));
  printf("O máximo múltiplo comum, recursivamente, é: %d \n",maxmc_rec(n1,n2));
  printf("\n*********************************\n");
  printf("Introduza o primeiro número: \n");

  scanf("%d",&n1);

  printf("Introduza o segundo número: \n");

  scanf("%d",&n2);

  printf("O máximo divisor comum é: %d \n",mdc(n1,n2));

  printf("\n*********************************\n");
  printf("Introduza um número: \n");

  scanf("%d",&n1);

  printf("A soma de números ímpares é: %d \n",soma_n_impares(n1));

  printf("A soma de números ímpares, recursivamente, é: %d \n",soma_n_impares_rec(n1));
  printf("\n*********************************\n");
  

printf("Introduza o primeiro número: \n");

  scanf("%d",&n1);

  printf("Introduza o segundo número: \n");

  scanf("%d",&n2);

  printf("O resto da divisão inteira é: %d \n",resto(n1,n2));

  printf("O resto da divisão inteira, recursivamente, é: %d \n",resto_rec(n1,n2));
	

  printf("\n*********************************\n");
  printf("Introduza o primeiro número: \n");

  scanf("%d",&n1);

  printf("Introduza o segundo número: \n");

  scanf("%d",&n2);

  printf("A divisão inteira entre os dois números escolhidos é: %d \n",div_int(n1,n2));

  printf("A divisão inteira entre os dois números escolhidos, recursivamente, é: %d \n",div_int_rec(n1,n2));

  printf("\n*********************************\n");
  */

  printf("Introduza um número: \n");

  scanf("%d",&n1);

  printf("Os divisores do número escolhido são: %d \n",divisores(n1));	

  printf("Os divisores do número escolhido, recursivamente, são: %d \n",divisoresrec(n1));
	
  return 0;

}


