﻿
#include <stdio.h>




/* 0 se não é primo, 1 se é primo */

int eprimo(int n)
{
  int res=1, i=2;

  while ((i<=n/2) && (res==1))

  {

    if (n%i == 0)

      res=0;

      i++;

  }
  return res;

}




int main()

{
  int n=1;

  printf("Primos: ");

  while (n<=100)

  {

    if (eprimo(n))

      printf(" %d ",n);

      n++;
 
 }
  return 0;
}

    


