﻿
#include <stdio.h>




int divisores(int n)
{

  int i=1, res=0;

  while (i<=n)
  {

    if (n%i == 0)

    {
      res++;
    }

  i++;

  }
  
return res;
}





int divisoresrec(int n)

{

  return divrecaux(n,n);

}



int divrecaux(int a, int b)

{

  int res=0;

  if (b>0)

  {
    if (a%b == 0)

      res = 1 + divrecaux(a, b-1);

    else

      res = divrecaux(a, b-1);
  }

  return res;
}






int main()

{

  int num=10;

  printf("Número de divisores=%d \n, Número de divisores recursivo=%d \n",divisores(num), divisoresrec(num));

  return 0;
}


