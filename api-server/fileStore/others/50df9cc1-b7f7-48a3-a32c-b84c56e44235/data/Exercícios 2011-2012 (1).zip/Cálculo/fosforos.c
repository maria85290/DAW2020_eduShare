﻿
#include <stdio.h>




void jogo()

{

  int f = 21, n;

  while (f != 1)

  {

    printf("Tire de 1 a 4 fósforos: \n");

    scanf("%d",&n);

    if (n<=4)

    {

      f = f-n;

      f = f-(5-n);

      printf ("Eu tiro %d fósforos, existe %d fósforos \n", (5-n), f);

    }

    else
      printf ("Jogada inválida");

  }

  printf ("Eu ganhei! \n");

}




int main()

{

  jogo();
	

  return 0;

}


