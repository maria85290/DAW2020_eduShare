﻿
#include <stdio.h>




/* 1 se valor pertence à sequência, 0 se não pertence */
int existe(int Seq[], int nelems, int valor)

{
  int i=0, e=0, flag=1;
  while ((i<=nelems) && flag)
  {

    if (valor == Seq[i])

      {
        e=1;

        flag=0;

      }

    i++;
  }
  return e;
}




int pos(int Seq[], int nelems, int valor)

{
  int i=0, res=0, flag=1;
  while ((i<=nelems) && flag)

  {

    if (valor == Seq[i])

    {

      res=i+1;

      flag=0;

    }

    i++;
 
 }

  return res;
}





int posrec(int Seq[], int nelems, int valor)

{
  int i=0, res=0;
  if (0>=nelems)

    res=0;

  else

    if (valor==Seq[i])

      res=nelems;

    else

      res= posrec(Seq, nelems-1, valor);
  
return res;
}




int main()

{

  int Seq[]={2,4,6,8,10};

  int nelem=5;

  int valor=6;

  printf("Existe:%d \n Pos:%d \n Posrec:%d \n",existe(Seq,nelem,valor), pos(Seq,nelem,valor), pos(Seq,nelem,valor));

  return 0;

}

  
    
