﻿
#include <stdio.h>





int bin2dec(char *s)
{


  int i=0, res=0;

  while (s[i] != '\0')
  {

    res = res * 2 + s[i]-'0';

    i++;
  }

  return res;
}




int main()
{

  char bin[]="1001";

  printf("O binário %s em decimal é: %d", bin, bin2dec(bin));

  return 0;

}


