﻿
#include <stdio.h>

#include <stdlib.h>




int lista(int A[], int nelems)

{

  int i=0;


  while (i<nelems)

  {

    printf("%d \n", A[i]);

    i++;

  }

  return nelems;

}






int somalista(int A[], int nelems)

{
  int res=0, i=0;

  while (i<nelems)

  {

    res=res+A[i];

    i++;
  }

  return res;
}






int somalistarec(int A[], int nelems)

{

  int res;

  if (nelems>0)

  {

    res = A[nelems-1] + somalista(A, nelems-1);

  }

  return res;
}
 





int minSeq(int A[],int nalunos)

{

  int res = A[0], i=1;

  while (i<nalunos)

  {

    if (res>A[i])

      res=A[i];

      i++;

  }

  return res;

}






int strlen(char *s)

{

  int res=0;

  while(*s != '\0')

  {

    res++;

    s++;

  }

  return res;

}




char* junta(char *s1, char *s2)

{

  int i, j;

  char *res;

  res=(char*)malloc(strlen(s1)+strlen(s2)+1);

  for (i=0; i<strlen(s1); i++)

  {

    res[i]=s1[i];

  }

  for (j=0; j<strlen(s2); j++)

  {

    res[j+i]=s2[j];

  }

  res[i+j]='\0';

  return res;

}




void ordenatrocas(int A[], int nelems)

{

  int trocas=1, i, aux;

  while (trocas)

  {

    trocas=0; i=0;

    while (i<nelems-1)

    {

      if (A[i]>A[i+1])

      {

        aux=A[i];

        A[i]=A[i+1];

        A[i+1]=aux;
        trocas=1;
      }

      i++;

    }

  }

  return 0;

}





int main()

{

  int A[]={5,4,3,2,1};

  ordenatrocas(A,5);

  lista(A,5);




  char *nome="José";

  char *nome2="Ramalho";

  printf("%s \n", junta(nome,nome2));

  /*
  
lista(Seq,10);


  printf("A soma da lista é: %d\n" , somalista(Seq,10));


  printf("A soma da lista em modo recursivo é: %d\n" , somalistarec(Seq,10));


  printf("O mínimo é %d\n" , minSeq(Seq,10));
  */
  

return 0;
}



