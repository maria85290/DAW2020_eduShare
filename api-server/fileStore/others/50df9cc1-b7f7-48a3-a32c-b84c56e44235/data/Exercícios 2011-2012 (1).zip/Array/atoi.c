﻿
#include <stdio.h>




int atoi(char *s)
{

  int i=0, res=0;

  while (s[i] != '\0')
  {

    res = (10 * res + s[i]-'0');

    i++;
  }

  return res;
}




int main()
{

  char st[] = "Ana";

  printf("O resultado é %d", atoi(st));

  return 0;

}



