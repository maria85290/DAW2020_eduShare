
#include <stdio.h>




int lerseq(int Seq[])

{

  int i=0;

  scanf("%d", &Seq[0]);

  while (i<10 && (Seq[i-1] != 0))
  {

    i++;

    scanf("%d", &Seq[i]);

  }

  return i;
}





float media(int Seq[], int nelems)

{

  float med=0;

  int i=0;
  int soma=0;
 
 while(i<nelems)
 
 {

    soma=soma+Seq[i];

    i++;

  }

  med=(soma/nelems);

  return med;
 
}




int supmedia(int Seq[], int nelems, float media)
{

  int res=0, i;

  for (i=0; i<nelems; i++)
  {
    if (Seq[i]>media)

      res++;

  }

  return res;
}





int main()

{
  int Seq[11], nelems;
  float med;

  nelems = lerseq(Seq);

  printf("nelems %d \n",nelems);

  med = media(Seq, nelems);

  printf("Existem %d  > media=%f\n", supmedia(Seq,nelems,med), med);

  return 0;

}


    
