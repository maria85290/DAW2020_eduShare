#!/usr/bin/python

import os, sys

# Gerar dois arrays (diferentes!!) de bytes de tamanhos adequados, a utilizar
# como chave para a cifra e para o mac. Estes valores deverão estar hardcoded em
# ambos ficheiros enc.py e dec.py.
key = None
hmackey = None

msg = "Isto é uma mensagem não muito secreta!"

def etm():
  # Implementar aqui o modo encrypt-then-mac

  w2f("dados-etm.dat", dados)

def eam():
  # Implementar aqui o modo encrypt-and-mac

  w2f("dados-eam.dat", dados)

def mte():
  # Implementar aqui o modo mac-then-encrypt

  w2f("dados-mte.dat", dados)

def w2f(nomeficheiro, data):
  with open(nomeficheiro, 'wb') as f:
    f.write(data)

def main():

  if len(sys.argv) != 2:
    print("Please provide one of: eam, etm, mte")
  elif sys.argv[1] == "eam":
    eam()
  elif sys.argv[1] == "etm":
    etm()
  elif sys.argv[1] == "mte":
    mte()
  else:
    print("Please provide one of: eam, etm, mte")

if __name__ == '__main__':
  main()
