#!/usr/bin/python

import os, sys

# Gerar dois arrays (diferentes!!) de bytes de tamanhos adequados, a utilizar
# como chave para a cifra e para o mac. Estes valores deverão estar hardcoded em
# ambos ficheiros enc.py e dec.py.
key = None
hmackey = None

def rff(nomeficheiro):
  with open(nomeficheiro, 'rb') as f:
    return f.read()

def etm():
  data = rff("dados-etm.dat")

  # Inverter aqui o modo encrypt-then-mac
  # E fazer print da mensagem descodificada

def eam():
  data = rff("dados-eam.dat")

  # Inverter aqui o modo encrypt-and-mac
  # E fazer print da mensagem descodificada

def mte():
  data = rff("dados-mte.dat")

  # Inverter aqui o modo mac-then-encrypt
  # E fazer print da mensagem descodificada

def main():

  if len(sys.argv) != 2:
    print("Please provide one of: eam, etm, mte")
  elif sys.argv[1] == "eam":
    eam()
  elif sys.argv[1] == "etm":
    etm()
  elif sys.argv[1] == "mte":
    mte()
  else:
    print("Please provide one of: eam, etm, mte")

if __name__ == '__main__':
  main()
