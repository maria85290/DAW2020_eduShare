typedef struct sListaInt
{
	int valor;
	struct sListaInt *seg;
} *ListaInt, NListaInt;

