import React from 'react'
import { Link, WrappedLink } from 'react-router-dom'
import { Button } from 'react-bootstrap'

class Header extends React.Component {

  render() {
    return (
      <h1>ESS Online Trading Platform</h1>
    );
  }
}

export default Header;
