#include "cinema.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// Lista de bilhetes vendidos está ordenada
int lugarDisponivel(LBilhete lista, int lugar){
    while(lista != NULL && lista->lugar != lugar)
        lista = lista->seg;
    
    return (lista != NULL) ? 0 : 1;
}

int disponivel( Cinema c, Filme f, int lugar ){
    while( c != NULL && strcmp(c->s.filme, f) != 0)
        c = c->seg;
    
    if(c != NULL)
        return lugarDisponivel( c->s.vendidos, lugar);
    else
        return 0;
}

LBilhete insBilhete(LBilhete lista, LBilhete b){
    if(lista == NULL || b->lugar < lista->lugar){
        b->seg = lista;
        return b;
    }
    else{
        lista->seg = insBilhete( lista->seg, b);
        return lista;
    }
}

Cinema vendeAux( Cinema c, Filme f, int lugar ){
    LBilhete bilhete;
    bilhete = malloc(sizeof(NLBilhete));
    bilhete->lugar = lugar;

    Cinema aux = c;

    while(strcmp(aux->s.filme, f) != 0)
        aux = aux->seg;

    aux->s.vendidos = insBilhete(aux->s.vendidos, bilhete);
    return c;
}


Cinema vendebilhete( Cinema c, Filme f, int lugar ){
    if(disponivel(c, f, lugar)) return vendeAux(c, f, lugar);
    else return c;
}

void listardisponibilidades( Cinema c );

Cinema inserirSala( Cinema c, Sala s){
    Cinema novo = malloc(sizeof(NCinema));
    novo->s = s;
    novo->seg = c;
    return novo; 
}

int contaVendidos(LBilhete lista){
	if (lista == NULL) return 0;
	return 1 + contaVendidos(lista->seg);
}

void listarSala( Sala s){
    printf("%s: lugares = %d, vendidos = %d, filme = %s\n", 
            s.nome, s.nlugares, contaVendidos(s.vendidos), s.filme);
}

void listar( Cinema c ){
    printf("----------------------------------------------\n");
    while(c != NULL) {
       listarSala(c->s);
        c = c->seg;
    }
}
