#include "cinema.h"
#include <stdlib.h>
#include <stdio.h>

int main()
{
    Sala s1 = {"Sala 1", 150, NULL, "Twilight"},
         s2 = {"Sala 2", 200, NULL, "Hannibal"};
    Cinema c1 = NULL;

    c1 = inserirSala(c1, s1);
    c1 = inserirSala(c1, s2);

    listar(c1);

    int i;
    for(i=1; i<101; i++){
        c1 = vendebilhete(c1, "Hannibal", i);
        c1 = vendebilhete(c1, "Hannibal", 40+i);
        c1 = vendebilhete(c1, "Twilight", 2*i);
    }

    listar(c1);

    /*if(disponivel(c1, "Twilight", 17 ))
        c1 = vendebilhete(c1, "Twilight", 17 );

    listardisponibilidades(c1);*/

  return 0;
}