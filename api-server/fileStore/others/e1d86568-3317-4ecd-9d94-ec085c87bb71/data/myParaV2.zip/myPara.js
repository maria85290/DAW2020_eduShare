$(document).ready(function(){
    $.get('http://localhost:7709/paras', function(data) {
        data.forEach(p => {
            $("#paraList").append("<li>"+ p.text + "</li>")
        })
    })
    $("#addPara").click(function(){
        $("#paraList").append("<li>"+ $("#paraText").val() + "</li>")
        $.post("http://localhost:7709/paras", $('#myParaForm').serialize()) //abreviatura AJAX no JQUERY. serialize constroi o objeto em javacript com todos os campos
        alert('Record inserted: ' + JSON.stringify($('#myParaForm').serialize())) //fazer com verificação
        $("#paraText").val("");
    })
})