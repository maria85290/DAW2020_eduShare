# ---------------------------------------------------------------------------------------------
# --------------------------------------  SQL FUNCTIONS  --------------------------------------
# ---------------------------------------------------------------------------------------------

# transform the year correctly
DELIMITER $$
DROP FUNCTION IF EXISTS concatString;
CREATE function concatString(dob VARCHAR(45)) returns date deterministic
BEGIN
	DECLARE correctDate VARCHAR(45);
    DECLARE inicio, ano, fim VARCHAR(10);
	SELECT SUBSTRING(dob, 1, 6) INTO inicio;
	SELECT SUBSTRING(dob, 7, 2) INTO ano;
SELECT SUBSTRING(dob, 9, 6) INTO fim;
    IF (CAST(ano AS decimal(10,2))) > 21 
		THEN SET correctDate=CONCAT(inicio,'19',ano,fim);
		ELSEIF (CAST(ano AS decimal(10,2))) <= 21 
			THEN SET correctDate=CONCAT(inicio,'20',ano,fim);
    END IF;
    return(STR_TO_DATE(correctDate, '%d/%m/%Y %H:%i'));
END $$
DELIMITER ;

# --------------------------------------------------------
DELIMITER $$
DROP FUNCTION IF EXISTS getPatientID;
CREATE function  getPatientID(dob date, gender VARCHAR(45), disct VARCHAR(45)) returns int deterministic
BEGIN
	return ( SELECT id_pacient
			 FROM Dim_Patient t1
			 WHERE t1.sex = gender 
				and t1.district = disct 
                and t1.date_of_birth = dob);
END $$
DELIMITER ;

# --------------------------------------------------------
DELIMITER $$
DROP FUNCTION IF EXISTS getDischargeID;
CREATE function  getDischargeID(disc_date datetime, idProf int) returns int deterministic
BEGIN
	return (SELECT id_discharge
			 FROM Dim_Discharge t2
			 WHERE t2.date_discharge = disc_date and t2.id_prof_discharge = idProf);
END $$
DELIMITER ;

# --------------------------------------------------------

DELIMITER $$
DROP FUNCTION IF EXISTS getDiagnosisID;
CREATE function  getDiagnosisID (diag_date datetime, diag_idProf int) returns int deterministic
BEGIN
	return (SELECT id_diagnosis 
			FROM Dim_Diagnosis t1
			WHERE t1.date_diagnosis = diag_date and t1.id_prof_diagnosis = diag_idProf);
END $$
DELIMITER ;

# --------------------------------------------------------
DELIMITER $$
DROP FUNCTION IF EXISTS getTriageID;
CREATE function  getTriageID (episode int, tri_date datetime, tri_idProf int, pain int, cor int ) returns int deterministic
BEGIN
	 return (SELECT id_triage
			 FROM Dim_Triage t1
	 	     WHERE t1.urge_episode = episode and t1.date_triage = tri_date  and t1.id_prof_triage = tri_idProf 
             and  t1.pain_scale = pain and t1.id_color = cor);
END $$
DELIMITER ;

# ---------------------------------------------------------------------------------------------
# ----------------------------------  ALTER TABLES QUERIES  -----------------------------------
# ---------------------------------------------------------------------------------------------

SET SQL_SAFE_UPDATES = 0;
alter table urgency_episodes add dob_corret DATE;
alter table urgency_episodes add triage_date DATETIME;
alter table urgency_episodes add urg_date DATETIME;
alter table urgency_episodes add discharge_date DATETIME;
alter table urgency_episodes add diagnosis_date DATETIME;
update urgency_episodes set dob_corret = concatString(date_of_birth);
update urgency_episodes set triage_date = STR_TO_DATE(dt_admition_traige, '%d/%m/%y %H:%i');
update urgency_episodes set urg_date = STR_TO_DATE(dt_admition_urg, '%d/%m/%y %H:%i');
update urgency_episodes set discharge_date = STR_TO_DATE(dt_discharge, '%d/%m/%y %H:%i');
update urgency_episodes set diagnosis_date = STR_TO_DATE(dt_diagnosis, '%d/%m/%y %H:%i');
alter table Fact_episode add (duration int, waiting_time int);
SET SQL_SAFE_UPDATES = 1;

# ---------------------------------------------------------------------------------------------
# -----------------------------------  INSERT QUERIES  ---------------------------------------
# ---------------------------------------------------------------------------------------------

# 1 ----------------------------------------------------------------------------------------
INSERT INTO Dim_Color (id_color, desc_color)  
SELECT DISTINCT id_color, desc_color
FROM urgency_episodes;

# 2 ----------------------------------------------------------------------------------------
INSERT INTO Dim_Patient (date_of_birth, age, sex, district)
SELECT distinct dob_corret,
	CASE WHEN DATEDIFF(CURDATE(), dob_corret) < CURDATE() 
		THEN round(DATEDIFF(CURDATE(), dob_corret) /365, 0) 
		ELSE round((DATEDIFF(CURDATE(), dob_corret) - 1) /365,0) END, 
	sex, 
	district
FROM urgency_episodes;

# 3 ----------------------------------------------------------------------------------------
INSERT INTO Dim_Reason(id_reason, desc_reason)
SELECT DISTINCT id_reason, desc_reason FROM urgency_episodes;

# 4 ----------------------------------------------------------------------------------------
INSERT INTO Dim_Cause(id_cause, description_cause)
SELECT DISTINCT id_ext_cause, desc_external_cause FROM urgency_episodes;

# 5 ----------------------------------------------------------------------------------------
INSERT INTO Dim_Destination (id_destination, desc_destination)
SELECT DISTINCT id_destination, desc_destination FROM urgency_episodes;

# 6 ----------------------------------------------------------------------------------------
INSERT INTO Dim_Intervention(id_intervention, description_interv)
SELECT DISTINCT id_intervention, desc_intervention FROM urgency_procedures;

# 7 ----------------------------------------------------------------------------------------
INSERT INTO Dim_Medicine (cod_med, desc_med)
SELECT DISTINCT cod_drug, desc_drug FROM urgency_prescriptions;

# 8 ----------------------------------------------------------------------------------------
INSERT INTO Dim_ICD9_Classification (cod_diagnosis, levelMax, description_level1, description_level2, description_level3, description_level4, description_level5)
SELECT case level_5_code when '' 
			then (case level_4_code when '' 
					then level_3_code 
                    else level_4_code end) 
			else level_5_code END, 
		case level_5_code when '' 
			then (case level_4_code when '' 
						then 3 else 4 end) 
                        else 5 END,
        level_1_desc, level_2_desc, level_3_desc, level_4_desc, case level_5_desc when '' then null else level_5_desc end
FROM icd9_hierarchy;


# 9 ----------------------------------------------------------------------------------------
INSERT INTO Dim_Diagnosis (date_diagnosis, desc_diagnosis, id_prof_diagnosis, id_classification)
SELECT STR_TO_DATE(t1.dt_diagnosis, '%d/%m/%Y %H:%i'), t1.diagnosis, t1.id_prof_diagnosis, t2.id_classification
FROM urgency_episodes t1, dim_icd9_classification t2
where t2.cod_diagnosis = cast(t1.cod_diagnosis as CHAR(45));

# 10 ----------------------------------------------------------------------------------------
INSERT INTO Dim_Discharge (date_discharge, id_prof_discharge, id_reason, id_destination)
SELECT STR_TO_DATE(t1.dt_discharge, '%d/%m/%Y %H:%i'), t1.id_prof_discharge, t2.id_reason, t3.id_destination
FROM urgency_episodes t1, Dim_Reason t2, Dim_Destination t3
WHERE t3.id_destination = t1.id_destination AND t2.id_reason = t1.id_reason;

# 11 ------------------------------------------------------------------------------
INSERT INTO Dim_Triage (date_triage, id_prof_triage, id_color, pain_scale)
SELECT t1.triage_date, t1.id_prof_triage, t2.id_color, t1.pain_scale
FROM urgency_episodes t1, dim_color t2
WHERE t1.id_color = t2.id_color;


# 12 ----------------------------------------------------------------------------
INSERT INTO Fact_Episode (id_urge_episode, id_paciente, id_cause, id_discharge, id_diagnosis, id_triage, duration, waiting_time)
SELECT t1.urg_episode, 
		(getPatientID(t1.dob_corret, t1.SEX, t1.DISTRICT)),
        t1.id_ext_cause,
        (getDischargeID(t1.discharge_date, t1.ID_PROF_DISCHARGE, t1.URG_EPISODE)),
        (getDiagnosisID(t1.diagnosis_date, t1.ID_PROF_DIAGNOSIS, t1.URG_EPISODE)),
        (getTriageID(t1.URG_EPISODE, t1.triage_date, t1.ID_PROF_TRIAGE, t1.PAIN_SCALE, t1.ID_COLOR)),
        TIMESTAMPDIFF(HOUR, t1.triage_date, t1.discharge_date), 
		TIMESTAMPDIFF(MINUTE, t1.urg_date, t1.triage_date)
FROM urgency_episodes t1;
	
# 13 ----------------------------------------------------------------------------
INSERT INTO Dim_Procedure (date_procedure, id_prescription, id_professional, id_intervention, description_procedure, id_triage)
SELECT STR_TO_DATE(t1.dt_begin, '%Y-%m-%d %H:%i:%s'), 
		t1.ID_PRESCRIPTION, t1.id_professional, t1.id_intervention, t1.note, 
		(SELECT id_triage 
		 FROM Fact_episode t2
         WHERE t1.URG_EPISODE = t2.id_urge_episode)
FROM urgency_procedures t1;

# 14 ----------------------------------------------------------------------------
INSERT INTO Dim_Prescription (cod_prescription, id_professional, date_presc, quantity, posology, id_cod_med, id_triage)
SELECT t1.cod_prescription, t1.id_prof_prescription, t1.dt_prescription, t1.qt, t1.posology, t2.id_cod_med,
		(SELECT id_triage 
		 FROM Fact_episode t3 
         WHERE t1.URG_EPISODE = t3.id_urge_episode)
FROM urgency_prescriptions t1, dim_medicine t2
WHERE t2.cod_med = t1.cod_drug;

# 15 ----------------------------------------------------------------------------------------
INSERT INTO Dim_Exam (cod_exam, desc_exame, id_triage)
SELECT DISTINCT t1.num_exam, t1.desc_exam,
				(SELECT id_triage
				 FROM Fact_episode t2
                 WHERE t1.URG_EPISODE = t2.id_urge_episode)
FROM urgency_exams t1;